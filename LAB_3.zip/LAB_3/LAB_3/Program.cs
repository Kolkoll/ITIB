﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LAB_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Reccurent_Neural_Network_of_Hophild obj = new Reccurent_Neural_Network_of_Hophild();
            obj.Point_of_entry();
        }
    }
}
